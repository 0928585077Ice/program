<?php
include 'includes/config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $user_id = $_SESSION["user_id"];
    $content = $_POST["content"];
    $image = "";

    if (!empty($_FILES["image"]["name"])) {
        $target_dir = "assets/uploads/";
        $image = $target_dir . basename($_FILES["image"]["name"]);
        move_uploaded_file($_FILES["image"]["tmp_name"], $image);
    }

    $sql = "INSERT INTO posts (user_id, content, image) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("iss", $user_id, $content, $image);
    $stmt->execute();
    header("Location: feed.php");
}
?>


<div class="w-100">

    <div class="d-flex align-items-center justify-content-between w-100 text-white shadow mb-3 bg-body-tertiary rounded p-4">

        <a href="profile.php?account_id=<?php echo $_SESSION['user_id']; ?>" class="d-flex align-items-center text-decoration-none p-2 rounded-pill">
            <div class="position-relative me-2">
                <div class="rounded-circle overflow-hidden" style="width: 48px; height: 48px;">
                    <?php if (!empty($_SESSION['avatar']) && file_exists($_SESSION['avatar'])): ?>
                        <img src="<?php echo $_SESSION['avatar']; ?>" alt="Profile Picture" class="d-flex align-items-center w-100 h-100 object-fit-cover">
                    <?php else: ?>
                        <ion-icon name="person-circle-outline" class="text-secondary" style="font-size: 48px;"></ion-icon>
                    <?php endif; ?>
                </div>
            </div>
        </a>

        <button type="button" data-bs-toggle="modal" data-bs-target="#exampleModal" class="w-100 text-start text-muted fw-semibold px-3 py-2 border rounded-pill">
            คุณคิดอะไรอยู่ <?php echo $_SESSION['username']; ?>
        </button>

    </div>

    <!-- Modal -->
    <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="modalPost" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">

                <form action="actions/upload_post.php" method="POST" enctype="multipart/form-data">
                    <div class="modal-header">
                        <h1 class="modal-title fs-5" id="modalPost">
                            <div class="d-flex align-items-center text-decoration-none p-2 rounded-pill">
                                <div class="position-relative me-2">
                                    <div class="rounded-circle overflow-hidden" style="width: 48px; height: 48px;">
                                        <?php if (!empty($_SESSION['avatar']) && file_exists($_SESSION['avatar'])): ?>
                                            <img src="<?php echo $_SESSION['avatar']; ?>" alt="Profile Picture" class="d-flex align-items-center w-100 h-100 object-fit-cover">
                                        <?php else: ?>
                                            <ion-icon name="person-circle-outline" class="text-secondary" style="font-size: 48px;"></ion-icon>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="text-start">
                                    <p class="mb-0 fw-semibold fs-6 text-dark"><?php echo $_SESSION['username']; ?></p>
                                    <p class="mb-0 text-muted fs-6 small"><?php echo $_SESSION['email']; ?></p>
                                </div>
                            </div>
                        </h1>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <div class="rounded-md bg-neutral-700 mb-3 p-3">

                            <div class="mb-3">
                                <label for="exampleFormControlTextarea1" class="form-label">เขียนอะไรบางอย่าง...</label>
                                <textarea name="post_text" rows="3" class="form-control" id="post" rows="3"></textarea>
                            </div>

                            <div id="previewContainer" class="mb-3 d-none border border-secondary rounded-md p-2 d-flex justify-content-center overflow-hidden">
                                <img id="imagePreview" class="w-100 h-auto object-fit-cover rounded-lg">
                            </div>

                            <div class="input-group mb-3">
                                <input type="file" name="post_image" id="fileInput" accept="image/*" class="form-control">
                                <label id="fileName" for="fileInput" class="input-group-text">เพิ่มรูปภาพ</label>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">ปิด</button>
                        <button type="submit" class="btn btn-primary">โพสต์</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script>
        document.addEventListener("DOMContentLoaded", function() {
            // อัปเดตการแสดงตัวอย่างรูป
            const fileInput = document.getElementById("fileInput");
            const fileName = document.getElementById("fileName");
            const previewContainer = document.getElementById("previewContainer");
            const imagePreview = document.getElementById("imagePreview");

            if (fileInput) {
                fileInput.addEventListener("change", function() {
                    const file = this.files[0];
                    if (file) {
                        const reader = new FileReader();

                        reader.onload = function(e) {
                            imagePreview.src = e.target.result;
                            previewContainer.classList.toggle("d-none", false);
                            fileName.textContent = "เปลี่ยนรูปภาพ";
                        };

                        reader.readAsDataURL(file);
                    } else {
                        previewContainer.classList.toggle("d-none", true);
                    }
                });
            }

            // อัปเดตการแสดงตัวอย่างรูปโปรไฟล์
            const profileInput = document.getElementById("profileInput");
            const previewProfile = document.getElementById("previewProfile");
            const ProfilePreview = document.getElementById("ProfilePreview");

            if (profileInput) {
                profileInput.addEventListener("change", function() {
                    const profile = this.files[0];
                    if (profile) {
                        const reader = new FileReader();

                        reader.onload = function(e) {
                            ProfilePreview.src = e.target.result;
                            previewProfile.classList.toggle("d-none", false);
                        };

                        reader.readAsDataURL(profile);
                    } else {
                        previewProfile.classList.toggle("d-none", true);
                    }
                });
            }
        });
    </script>


</div>
