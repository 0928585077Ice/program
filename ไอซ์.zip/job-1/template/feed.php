<?php
include 'includes/config.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: includes/login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
?>

<?php
$result = $conn->query("SELECT posts.*, users.username, users.avatar,
                        (SELECT COUNT(*) FROM likes WHERE post_id = posts.id) AS like_count,
                        (SELECT COUNT(*) FROM likes WHERE post_id = posts.id AND user_id = $user_id) AS user_liked
                        FROM posts 
                        JOIN users ON posts.user_id = users.id 
                        ORDER BY posts.updated_at DESC");

function formatNumber($num)
{
    if ($num >= 1000000) {
        return number_format($num / 1000000, 1) . 'M';
    } elseif ($num >= 1000) {
        return number_format($num / 1000, 1) . 'K';
    }
    return $num;
}

?>

<?php
function timeAgo($timestamp)
{
    date_default_timezone_set('Asia/Bangkok'); // ตั้งค่า timezone ให้ตรงกับเขตเวลาในประเทศไทย
    $time_ago = strtotime($timestamp);
    $current_time = time();
    $time_difference = $current_time - $time_ago;

    $seconds = $time_difference;
    $minutes      = round($seconds / 60);
    $hours        = round($seconds / 3600);
    $days         = round($seconds / 86400);
    $weeks        = round($seconds / 604800);
    $months       = round($seconds / 2629440);
    $years        = round($seconds / 31553280);

    if ($seconds <= 60) {
        return "ไม่กี่วินาทีที่แล้ว";
    } else if ($minutes <= 60) {
        if ($minutes == 1) {
            return "1 นาทีที่แล้ว";
        } else {
            return "$minutes นาทีที่แล้ว";
        }
    } else if ($hours <= 24) {
        if ($hours == 1) {
            return "1 ชั่วโมงที่แล้ว";
        } else {
            return "$hours ชั่วโมงที่แล้ว";
        }
    } else if ($days <= 7) {
        if ($days == 1) {
            return "1 วันที่แล้ว";
        } else {
            return "$days วันที่แล้ว";
        }
    } else if ($weeks <= 4.3) {
        if ($weeks == 1) {
            return "1 สัปดาห์ที่แล้ว";
        } else {
            return "$weeks สัปดาห์ที่แล้ว";
        }
    } else if ($months <= 12) {
        if ($months == 1) {
            return "1 เดือนที่แล้ว";
        } else {
            return "$months เดือนที่แล้ว";
        }
    } else {
        if ($years == 1) {
            return "1 ปีที่แล้ว";
        } else {
            return "$years ปีที่แล้ว";
        }
    }
}

?>

<style>
    .dropdown-toggle::after {
        display: none;
    }
</style>

<?php while ($row = $result->fetch_assoc()): ?>
    <div class="post rounded shadow-lg mb-4 p-3 w-100">

        <div class="d-flex w-100 justify-content-between align-items-center">
            <a href="profile.php?account_id=<?php echo $row['user_id']; ?>" class="d-flex align-items-center text-decoration-none text-dark">
                <!-- Avatar -->
                <div class="d-flex align-items-center justify-content-center rounded-circle overflow-hidden me-2" style="width: 40px; height: 40px;">
                    <?php if (!empty($row['avatar']) && file_exists($row['avatar'])): ?>
                        <img src="<?php echo $row['avatar']; ?>" alt="Profile Picture" class="w-100 h-100 object-fit-cover">
                    <?php else: ?>
                        <ion-icon name="person-circle-outline" class="text-secondary display-6"></ion-icon>
                    <?php endif; ?>
                </div>

                <div>
                    <div class="d-flex align-items-center">
                        <p class="fw-semibold me-2 mb-0"><?php echo $row['username']; ?></p>
                    </div>
                    <p class="text-muted small"><?php echo timeAgo($row['updated_at']); ?></p>
                </div>
            </a>

            <?php if ($user_id == $row['user_id']): ?>
                <div class="dropdown">
                    <button class="btn btn-secondary dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false" style="border: none;">
                        <ion-icon name="menu-outline" class="fs-4"></ion-icon>
                    </button>

                    <ul class="dropdown-menu">
                        <li>
                            <a href="#" class="dropdown-item text-dark d-flex align-items-center edit-post"
                                data-id="<?= $row['id'] ?>" data-content="<?= htmlspecialchars($row['content']) ?>">
                                <ion-icon name="pencil-outline" class="me-2"></ion-icon> แก้ไข
                            </a>
                        </li>
                        <li>
                            <a href="#" class="dropdown-item text-dark d-flex align-items-center delete-post"
                                data-id="<?= $row['id'] ?>">
                                <ion-icon name="trash-bin-outline" class="me-2"></ion-icon> ลบ
                            </a>
                        </li>
                    </ul>
                </div>

            <?php endif; ?>
        </div>


        <p class="post-content text-dark mt-2"><?= htmlspecialchars($row['content']) ?></p>

        <?php if (!empty($row['image_path'])): ?>
            <div class="d-flex justify-content-center overflow-hidden">
                <img src="<?= $row['image_path'] ?>" alt="โพสต์รูปภาพ" class="mt-4 rounded img-fluid" style="max-width: 100%; height: auto; object-fit: cover;">
            </div>
        <?php endif; ?>


        <?php
        $commentCount = $conn->query("SELECT COUNT(*) as count FROM comments WHERE post_id = {$row['id']}")->fetch_assoc()['count'];
        ?>

        <hr class="border-top border-secondary my-2">

        <!-- ปุ่มไลค์ -->
        <div class="w-100 d-flex align-items-center justify-content-between text-dark gap-2">
            <div class="comment-count small text-secondary">
                <?php echo formatNumber($commentCount); ?> ความคิดเห็น
            </div>

            <div class="d-flex align-items-center text-dark gap-2">
                <span id="like-count-<?= $row['id'] ?>" class="fw-semibold">
                    <?= formatNumber($row['like_count']); ?>
                </span>
                <a href="#" class="like-button text-danger text-decoration-none d-flex align-items-center"
                    data-id="<?= $row['id'] ?>"
                    data-action="<?= ($row['user_liked'] > 0) ? 'unlike' : 'like' ?>">
                    <?= ($row['user_liked'] > 0) ?
                        '<ion-icon name="heart" class="fs-4 text-danger"></ion-icon>' :
                        '<ion-icon name="heart-outline" class="fs-4"></ion-icon>' ?>
                </a>
            </div>
        </div>


        <hr class="border-t border-gray-500 my-2">
        <!-- ฟอร์มแสดงความคิดเห็น -->
        <?php if ($user_id): ?>
            <form class="comment-form mt-4 d-flex align-items-center w-100">
                <input type="hidden" name="post_id" value="<?= $row['id'] ?>">
                <input type="text" name="content" required placeholder="เขียนความคิดเห็น..."
                    class="form-control me-3 px-3 py-2 border border-secondary rounded-pill shadow-sm">
                <button type="submit" class="btn p-2 text-dark border-0 bg-transparent">
                    <ion-icon name="send" class="fs-4"></ion-icon>
                </button>
            </form>
        <?php endif; ?>


        <?php if ($commentCount > 0): ?>
            <hr class="border-t border-gray-500 my-4">
        <?php endif; ?>


        <!-- แสดงคอมเมนต์ -->
        <div class="rounded-lg max-h-80 cursor-pointer overflow-y-auto rounded-lg">
            <?php
            $comments = $conn->query("SELECT comments.*,users.username, users.avatar FROM comments 
                      JOIN users ON comments.user_id = users.id 
                      WHERE comments.post_id = {$row['id']} ORDER BY comments.updated_at ASC");

            while ($comment = $comments->fetch_assoc()):
            ?>
                <div id="comments-<?= $row['id'] ?>" class="rounded shadow-sm overflow-auto" style="max-height: 320px;">
                    <?php
                    $comments = $conn->query("SELECT comments.*, users.username, users.avatar FROM comments 
              JOIN users ON comments.user_id = users.id 
              WHERE comments.post_id = {$row['id']} ORDER BY comments.updated_at ASC");

                    while ($comment = $comments->fetch_assoc()):
                    ?>
                        <div id="comment-<?= $comment['id'] ?>" class="d-flex align-items-start mb-3">
                            <!-- Avatar & Profile Link -->
                            <a href="profile.php?account_id=<?php echo $comment['user_id']; ?>" class="me-3">
                                <div class="rounded-circle overflow-hidden" style="width: 40px; height: 40px;">
                                    <?php if (!empty($comment['avatar']) && file_exists($comment['avatar'])): ?>
                                        <img src="<?= $comment['avatar'] ?>" alt="Profile Picture" class="w-100 h-100 object-cover">
                                    <?php else: ?>
                                        <ion-icon name="person-circle-outline" class="text-secondary fs-1"></ion-icon>
                                    <?php endif; ?>
                                </div>
                            </a>

                            <!-- Comment Content -->
                            <div class="flex-grow-1">
                                <div class="d-flex align-items-center mb-1">
                                    <div>
                                        <p class="fw-semibold mb-0"><?= $comment['username']; ?></p>
                                        <p class="text-muted small"><?= timeAgo($comment['updated_at']); ?></p>
                                    </div>
                                    <?php if ($user_id == $comment['user_id']): ?>
                                        <!-- Dropdown Menu -->
                                        <div class="dropdown ms-3">
                                            <button class="btn btn-sm text-secondary p-0 border-0" type="button" data-bs-toggle="dropdown">
                                                <ion-icon name="ellipsis-vertical" class="fs-5"></ion-icon>
                                            </button>
                                            <ul class="dropdown-menu dropdown-menu-end text-dark">
                                                <li>
                                                    <a class="dropdown-item text-dark edit-comment" href="#"
                                                        data-id="<?= $comment['id'] ?>"
                                                        data-content="<?= htmlspecialchars($comment['content']) ?>">
                                                        <ion-icon name="pencil-outline" class="me-1"></ion-icon> แก้ไข
                                                    </a>
                                                </li>
                                                <li>
                                                    <a class="dropdown-item text-danger delete-comment" href="#" data-id="<?= $comment['id'] ?>">
                                                        <ion-icon name="trash-bin-outline" class="me-1"></ion-icon> ลบ
                                                    </a>
                                                </li>
                                            </ul>
                                        </div>
                                    <?php endif; ?>
                                </div>

                                <!-- Comment Text -->
                                <div class="bg-secondary text-light p-2 rounded w-auto d-inline-block">
                                    <span class="comment-content"><?= htmlspecialchars($comment['content']) ?></span>
                                </div>
                            </div>
                        </div>
                    <?php endwhile; ?>
                </div>

            <?php endwhile; ?>
        </div>


    </div>
<?php endwhile; ?>

<script>
    $(document).ready(function() {
        // แก้ไขโพสต์
        $(document).on("click", ".edit-post", function(e) {
            e.preventDefault();

            let button = $(this);
            let postId = button.data("id");
            let postElement = button.closest(".post");
            let contentElement = postElement.find(".post-content");

            // ถ้ามี textarea อยู่แล้ว ก็ไม่ให้เปิดใหม่
            if (contentElement.find("textarea").length > 0) return;

            let oldContent = contentElement.text().trim();

            // สร้าง textarea สำหรับการแก้ไข
            let textarea = $(`<textarea class="w-100 p-2 text-dark rounded">${oldContent}</textarea>`);
            contentElement.html(textarea);
            textarea.focus();

            // เมื่อ textarea สูญเสีย focus หรือกด Enter
            textarea.on("blur keyup", function(e) {
                if (e.type === "blur" || (e.type === "keyup" && e.key === "Enter" && !e.shiftKey)) {
                    let newContent = textarea.val().trim();

                    // ถ้าเนื้อหาใหม่เหมือนเดิมหรือว่าง ให้คืนค่าเป็นเนื้อหาก่อนหน้า
                    if (newContent === "" || newContent === oldContent) {
                        contentElement.html(oldContent);
                        return;
                    }

                    // ส่งข้อมูลผ่าน AJAX
                    $.ajax({
                        url: "actions/edit_post.php",
                        type: "POST",
                        data: {
                            id: postId,
                            content: newContent
                        },
                        dataType: "json",
                        success: function(response) {
                            if (response.status === "success") {
                                contentElement.html(response.content);
                                button.data("content", response.content);
                            } else {
                                alert(response.message);
                                contentElement.html(oldContent);
                            }
                        },
                        error: function() {
                            alert("เกิดข้อผิดพลาดในการแก้ไขโพสต์");
                            contentElement.html(oldContent);
                        }
                    });
                }
            });
        });

        // ลบโพสต์
        $(document).on("click", ".delete-post", function(e) {
            e.preventDefault();
            if (!confirm("คุณแน่ใจหรือไม่ว่าต้องการลบโพสต์นี้?")) return;

            let button = $(this);
            let postId = button.data("id");

            $.ajax({
                url: "actions/delete_post.php",
                type: "POST",
                data: {
                    id: postId
                },
                dataType: "json",
                success: function(response) {
                    if (response.status === "success") {
                        button.closest(".post").remove();
                    }
                },
                error: function() {
                    alert("เกิดข้อผิดพลาดในการลบโพสต์");
                    console.log(data);
                    contentElement.html(oldContent);
                }
            });
        });

        // กดไลค์ / ยกเลิกไลค์
        $(document).on("click", ".like-button", function(e) {
            e.preventDefault();
            let button = $(this);
            let postId = button.data("id");
            let action = button.data("action");

            $.ajax({
                url: "actions/like_post.php",
                type: "GET",
                data: {
                    id: postId,
                    action: action
                },
                dataType: "json",
                success: function(response) {
                    if (response.status === "success") {
                        let newAction = response.action === "like" ? "unlike" : "like";
                        let newIcon = response.action === "like" ? "heart" : "heart-outline";

                        button.data("action", newAction);
                        button.find("ion-icon").attr("name", newIcon);
                        $("#like-count-" + postId).text(response.like_count);
                    }
                }
            });
        });

        function timeAgo(dateString) {
            const now = new Date();
            const date = new Date(dateString);
            const seconds = Math.floor((now - date) / 1000);
            const minutes = Math.floor(seconds / 60);
            const hours = Math.floor(minutes / 60);
            const days = Math.floor(hours / 24);
            const weeks = Math.floor(days / 7);
            const months = Math.floor(days / 30.42); // คำนวณเดือนเฉลี่ย
            const years = Math.floor(days / 365);

            if (seconds <= 60) {
                return "ไม่กี่วินาทีที่แล้ว";
            } else if (minutes <= 60) {
                return minutes === 1 ? "1 นาทีที่แล้ว" : `${minutes} นาทีที่แล้ว`;
            } else if (hours <= 24) {
                return hours === 1 ? "1 ชั่วโมงที่แล้ว" : `${hours} ชั่วโมงที่แล้ว`;
            } else if (days <= 7) {
                return days === 1 ? "1 วันที่แล้ว" : `${days} วันที่แล้ว`;
            } else if (weeks <= 4.3) {
                return weeks === 1 ? "1 สัปดาห์ที่แล้ว" : `${weeks} สัปดาห์ที่แล้ว`;
            } else if (months <= 12) {
                return months === 1 ? "1 เดือนที่แล้ว" : `${months} เดือนที่แล้ว`;
            } else {
                return years === 1 ? "1 ปีที่แล้ว" : `${years} ปีที่แล้ว`;
            }
        }


        // เพิ่มความคิดเห็น
        $(document).on("submit", ".comment-form", function(e) {
            e.preventDefault();
            let form = $(this);
            let postId = form.find("input[name='post_id']").val();
            let content = form.find("input[name='content']").val().trim();

            if (content === "") return;

            $.ajax({
                url: "actions/add_comment.php",
                type: "POST",
                data: {
                    post_id: postId,
                    content: content
                },
                dataType: "json",
                success: function(response) {
                    if (response.status === "success") {
                        const timeAgoText = timeAgo(response.updated_at);

                        const newComment = `
                <div id="comment-${response.comment_id}" class="d-flex align-items-start mb-3">
                    <a href="profile.php?account_id=${response.user_id}" class="me-3">
                        <div class="rounded-circle overflow-hidden" style="width: 40px; height: 40px;">
                            ${response.avatar
                                ? `<img src="${response.avatar}" alt="Profile Picture" class="w-100 h-100 object-cover">`
                                : `<ion-icon name="person-circle-outline" class="text-secondary fs-1"></ion-icon>`}
                        </div>
                    </a>

                    <div class="flex-grow-1">
                        <div class="d-flex align-items-center mb-1">
                            <div>
                                <p class="fw-semibold mb-0">${response.username}</p>
                                <p class="text-muted small">${timeAgoText}</p>
                            </div>
                            <!-- Dropdown Menu -->
                            <div class="dropdown ms-3">
                                <button class="btn btn-sm text-secondary p-0 border-0" type="button" data-bs-toggle="dropdown">
                                    <ion-icon name="ellipsis-vertical" class="fs-5"></ion-icon>
                                </button>
                                <ul class="dropdown-menu dropdown-menu-end text-dark">
                                    <li>
                                        <a class="dropdown-item text-dark edit-comment" href="#" data-id="${response.comment_id}" data-content="${response.content}">
                                            <ion-icon name="pencil-outline" class="me-1"></ion-icon> แก้ไข
                                        </a>
                                    </li>
                                    <li>
                                        <a class="dropdown-item text-danger delete-comment" href="#" data-id="${response.comment_id}">
                                            <ion-icon name="trash-bin-outline" class="me-1"></ion-icon> ลบ
                                        </a>
                                    </li>
                                </ul>
                            </div>
                        </div>

                        <!-- Comment Text -->
                        <div class="bg-secondary text-light p-2 rounded w-auto d-inline-block">
                            <span class="comment-content">${response.content}</span>
                        </div>
                    </div>
                </div>`;

                        // เพิ่มคอมเมนต์ใหม่เข้าไปใน container
                        $("#comments-" + postId).append(newComment);

                        // เคลียร์ข้อความในฟอร์ม
                        form.find("input[name='content']").val("");
                    }
                },
                error: function() {
                    alert("เกิดข้อผิดพลาดในการคอมเม้น");
                }
            });
        });

        // แก้ไขความคิดเห็น
        $(document).on("click", ".edit-comment", function(e) {
            e.preventDefault();

            let button = $(this);
            let commentId = button.data("id");
            let commentElement = $("#comment-" + commentId);
            let contentElement = commentElement.find(".comment-content");

            // ถ้ามี textarea อยู่แล้วให้ return
            if (contentElement.find("textarea").length > 0) return;

            // ใช้ data() เก็บค่าคอมเมนต์เดิม เพื่อไม่ให้หายเมื่อกดแก้ไขหลายครั้ง
            let oldContent = button.data("content") || contentElement.find(".comment-text").text().trim();
            button.data("content", oldContent); // อัปเดตค่าเดิมใน data()

            let textarea = $(`<textarea class="w-full p-2 bg-neutral-700 text-dark rounded">${oldContent}</textarea>`);
            contentElement.html(textarea);
            textarea.focus();

            textarea.on("blur keyup", function(e) {
                let newContent = textarea.val().trim();

                // บันทึกเมื่อกด Enter (แต่ไม่ใช่ Shift+Enter) หรือหลุดโฟกัส
                if (e.type === "blur" || (e.type === "keyup" && e.key === "Enter" && !e.shiftKey)) {
                    e.preventDefault();

                    // ถ้าข้อมูลเหมือนเดิม หรือเป็นค่าว่าง ให้คืนค่าเดิม
                    if (newContent === "" || newContent === oldContent) {
                        contentElement.html(`<span class="comment-text">${oldContent}</span>`);
                        return;
                    }

                    $.ajax({
                        url: "actions/edit_comment.php",
                        type: "POST",
                        data: {
                            id: commentId,
                            content: newContent
                        },
                        dataType: "json",
                        success: function(response) {
                            if (response.status === "success") {
                                contentElement.html(`<span class="comment-text">${response.content}</span>`);
                                button.data("content", response.content); // อัปเดตค่าใหม่
                            } else {
                                alert(response.message);
                                contentElement.html(`<span class="comment-text">${oldContent}</span>`);
                            }
                        },
                        error: function() {
                            alert("เกิดข้อผิดพลาดในการแก้ไขคอมเมนต์");
                            contentElement.html(`<span class="comment-text">${oldContent}</span>`);
                        }
                    });
                }

                // ยกเลิกเมื่อกด Escape
                else if (e.type === "keyup" && e.key === "Escape") {
                    contentElement.html(`<span class="comment-text">${oldContent}</span>`);
                }
            });
        });


        // ลบความคิดเห็น
        $(document).on("click", ".delete-comment", function(e) {
            e.preventDefault();
            if (!confirm("คุณแน่ใจหรือไม่ว่าต้องการลบคอมเมนต์นี้?")) return;

            let button = $(this);
            let commentId = button.data("id");
            let commentElement = $("#comment-" + commentId);
            let contentElement = commentElement.next(".comment-content");

            $.ajax({
                url: "actions/delete_comment.php",
                type: "POST",
                data: {
                    id: commentId
                },
                dataType: "json",
                success: function(response) {
                    if (response.status === "success") {
                        commentElement.fadeOut(300).promise().done(function() {
                            $(this).remove();
                        });
                        contentElement.fadeOut(300).promise().done(function() {
                            $(this).remove();
                        });
                    } else {
                        alert(response.message);
                    }
                },
                error: function(xhr, status, error) {
                    console.log("เกิดข้อผิดพลาด:", xhr.responseText);
                    alert("เกิดข้อผิดพลาดในการลบคอมเมนต์");
                }
            });
        });


    });
</script>

</html>