
<?php
include 'includes/config.php';
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: includes/login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
?>

<style>
    .nav-custom {
        background: #26547D;
    }
</style>

<nav class="navbar fixed-top shadow mb-5  nav-custom">
    <?php
    $user_id = $_SESSION['user_id'] ?? null;
    ?>
    <div class="container-lg">
        <?php if ($user_id): ?>
            <a href="index.php" class="d-flex align-items-center text-decoration-none p-2 rounded-pill">
                <div class="position-relative me-2">
                    <div class="rounded-circle shadow-lg overflow-hidden" style="width: 48px; height: 48px;">
                        <?php if (!empty($_SESSION['avatar']) && file_exists($_SESSION['avatar'])): ?>
                            <img src="<?php echo $_SESSION['avatar']; ?>" alt="Profile Picture" class="d-flex align-items-center w-100 h-100 object-fit-cover">
                        <?php else: ?>
                            <ion-icon name="person-circle-outline" class="text-secondary" style="font-size: 48px;"></ion-icon>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="text-start">
                    <p class="mb-0 fw-semibold fs-5 text-dark"><?php echo $_SESSION['username']; ?></p>
                    <p class="mb-0 text-muted small"><?php echo $_SESSION['email']; ?></p>
                </div>
            </a>

            <button class="navbar-toggler" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasNavbar" aria-controls="offcanvasNavbar" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="offcanvas offcanvas-end" tabindex="-1" id="offcanvasNavbar" aria-labelledby="offcanvasNavbarLabel">
                <div class="offcanvas-header">
                    <a href="index.php" class="d-flex align-items-center text-decoration-none p-2 rounded-pill">
                        <div class="position-relative me-2">
                            <div class="rounded-circle shadow-lg overflow-hidden" style="width: 48px; height: 48px;">
                                <?php if (!empty($_SESSION['avatar']) && file_exists($_SESSION['avatar'])): ?>
                                    <img src="<?php echo $_SESSION['avatar']; ?>" alt="Profile Picture" class="d-flex align-items-center w-100 h-100 object-fit-cover">
                                <?php else: ?>
                                    <ion-icon name="person-circle-outline" class="text-secondary" style="font-size: 48px;"></ion-icon>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="text-start">
                            <p class="mb-0 fw-semibold fs-5 text-dark"><?php echo $_SESSION['username']; ?></p>
                            <p class="mb-0 text-muted small"><?php echo $_SESSION['email']; ?></p>
                        </div>
                    </a>
                    <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
                </div>
                <div class="offcanvas-body d-flex flex-column vh-100">
                    <ul class="navbar-nav justify-content-start flex-grow-1 pe-3">
                        <li class="nav-item">
                            <a class="nav-link active" aria-current="page" href="index.php">หน้าหลัก</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link active" aria-current="page" href="profile.php?account_id=<?php echo $_SESSION['user_id']; ?>">โปรไฟล์</a>
                        </li>
                    </ul>

                    <?php if ($user_id): ?>
                        <!-- ปุ่มออกจากระบบ อยู่ล่างสุด -->
                        <a href="includes/logout.php" id="logoutLink" class="btn btn-danger d-flex align-items-center justify-content-center fs-6 mt-auto">
                            <ion-icon name="log-out-outline" class="me-1 fs-4"></ion-icon> ออกจากระบบ
                        </a>
                    <?php endif; ?>
                </div>

            </div>
        <?php else: ?>
        <?php endif; ?>
    </div>
</nav>
