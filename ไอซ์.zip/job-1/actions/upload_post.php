<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();
include '../includes/config.php'; // เชื่อมต่อฐานข้อมูล

if (!isset($_SESSION['user_id'])) {
    $_SESSION['error'] = "คุณต้องล็อกอินก่อนโพสต์!";
    header("Location: ../index.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$post_text = isset($_POST['post_text']) ? trim($_POST['post_text']) : '';
$image_path = null;

// ตรวจสอบว่ามีข้อมูลอย่างใดอย่างหนึ่ง (ข้อความหรือรูปภาพ)
if (empty($post_text) && empty($_FILES['post_image']['name'])) {
    $_SESSION['error'] = "ต้องกรอกข้อความหรืออัปโหลดรูปภาพอย่างน้อย 1 อย่าง!";
    header("Location: ../index.php");
    exit();
}

// ตรวจสอบและอัปโหลดไฟล์รูปภาพ
if (!empty($_FILES['post_image']['name'])) {
    $target_dir = "../assets/uploads/";
    if (!is_dir($target_dir)) {
        mkdir($target_dir, 0777, true);
    }

    $file = $_FILES['post_image'];
    $imageFileType = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    $allowed_types = ['jpg', 'jpeg', 'png', 'gif'];

    if (!in_array($imageFileType, $allowed_types)) {
        $_SESSION['error'] = "รองรับเฉพาะไฟล์ JPG, JPEG, PNG, GIF เท่านั้น!";
        header("Location: ../index.php");
        exit();
    }

    if ($file['size'] > 5 * 1024 * 1024) {
        $_SESSION['error'] = "ไฟล์มีขนาดใหญ่เกินไป (ต้องไม่เกิน 5MB)!";
        header("Location: ../index.php");
        exit();
    }

    $random = bin2hex(random_bytes(5));
    $new_image_name = time() . "_" . $random . "." . $imageFileType;
    $target_file = $target_dir . $new_image_name;

    if (move_uploaded_file($file['tmp_name'], $target_file)) {
        $image_path = "assets/uploads/" . $new_image_name;
    } else {
        $_SESSION['error'] = "เกิดข้อผิดพลาดในการอัปโหลดไฟล์!";
        header("Location: ../index.php");
        exit();
    }
}

// บันทึกโพสต์ลงฐานข้อมูล
$stmt = $conn->prepare("INSERT INTO posts (user_id, content, image_path) VALUES (?, ?, ?)");
$stmt->bind_param("iss", $user_id, $post_text, $image_path);

if ($stmt->execute()) {
    $_SESSION['success'] = "โพสต์ของคุณถูกเผยแพร่เรียบร้อย!";
} else {
    $_SESSION['error'] = "เกิดข้อผิดพลาดในการโพสต์ กรุณาลองใหม่!";
}

$stmt->close();
$conn->close();

header("Location: ../index.php");
exit();
