<?php
session_start();
include 'config.php';

$message = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST["username"];
    $password = $_POST["password"];

    $sql = "SELECT * FROM users WHERE username = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();

    if ($user && password_verify($password, $user["password"])) {
        $_SESSION["user_id"] = $user["id"];
        $_SESSION["username"] = $user["username"];
        $_SESSION["avatar"] = $user["avatar"];
        $_SESSION["email"] = $user["email"];
        $_SESSION["created_at"] = $user["created_at"];
        $_SESSION["updated_at"] = $user["updated_at"];
        header("Location: ../index.php");
        exit;
    } else {
        $message = "ชื่อผู้ใช้หรือรหัสผ่านไม่ถูกต้อง";
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <title>Social Network</title>
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
</head>

<body class="d-flex justify-content-center align-items-center" style="min-height: 100vh;">

    <div class="container" data-aos="fade-up">
        <div class="row justify-content-center">
            <div class="col-md-4 col-10 border p-4 rounded">
                <!-- Title -->
                <h2 class="text-center mb-4">เข้าสู่ระบบ</h2>

                <!-- Login Form -->
                <form action="#" method="POST">
                    <div class="mb-3">
                        <label for="username" class="form-label">ชื่อผู้ใช้</label>
                        <input type="text" class="form-control" name="username" id="username" autocomplete="username" required>
                    </div>
                    <div class="mb-3">
                        <label for="password" class="form-label">รหัสผ่าน</label>
                        <input type="password" class="form-control" name="password" id="password" autocomplete="current-password" required>
                    </div>
                    <?php if ($message): ?>
                        <div class="text-center">
                            <p class="text-danger"><?php echo $message; ?></p>
                        </div>
                    <?php endif; ?>
                    <button type="submit" class="btn btn-primary w-100 mb-2">เข้าสู่ระบบ</button>
                </form>

                <p class="mt-10 text-center text-sm/6 text-gray-500">
                    ยังไม่ได้ลงทะเบียน?
                    <a href="register.php" class="font-semibold text-gray-600 hover:text-gray-500">ลงทะเบียน</a>
                </p>
            </div>
        </div>
    </div>

    <?php include('../template/footer.php'); ?>