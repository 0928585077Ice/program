<?php include('template/header.php'); ?>

<?php include('template/navbar.php'); ?>

<?php include('template/sidebar.php'); ?>

<?php include('template/feed.php'); ?>

<?php include('template/footer.php'); ?>